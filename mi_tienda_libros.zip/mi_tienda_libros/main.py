from menu import mostrar_menu
from gestion_libros.inventario import agregar_libro, mostrar_inventario
from gestion_libros.ventas import vender_libro, mostrar_ventas

def main():
    inventario = {}
    ventas = {}
    while True:
        mostrar_menu()
        opcion = input("Ingrese una opción: ")
        if opcion == "1":
            agregar_libro(inventario)
        elif opcion == "2":
            mostrar_inventario(inventario)
        elif opcion == "3":
            vender_libro(inventario, ventas)
        elif opcion == "4":
            mostrar_ventas(ventas)
        elif opcion == "5":
            print("Saliendo del programa...")
            break
        else:
            print("Opción inválida. Intente nuevamente.")

if __name__ == "__main__":
    main()



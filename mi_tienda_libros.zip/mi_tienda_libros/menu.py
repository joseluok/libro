def mostrar_menu():
    """Muestra el menu principal"""
    print("\n---Menu de la tienda de libros---")
    print("1. Agregar libros al inventario")
    print("2. Mostrar inventario")
    print("3. Vender libros")
    print("4. Mostrar total de ventas")
    print("5. Salir")
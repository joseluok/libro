def vender_libro(inventario, ventas):

    """Vende un libro"""
    
    titulo = input("Ingrese el título del libro que desea vender: ")

    if titulo in inventario:
        cantidad_vendida = int(input("Ingrese la cantidad de libros que desea vender: "))
        
        if cantidad_vendida <= inventario[titulo]["cantidad"]:
            inventario[titulo]["cantidad"] -= cantidad_vendida
            ventas[titulo] = ventas.get(titulo, 0) + cantidad_vendida
            print(f"Se vendió {cantidad_vendida} copias del libro '{titulo}'.")
        else:
        
            print("No hay suficientes copias del libro en el inventario.")
    else:
        print("El libro no existe en el inventario.")


def mostrar_ventas(ventas):
    """Muestra el total de ventas"""

    print("\n---Total de ventas---")

    for titulo, cantidad in ventas.items():
        print(f"Titulo: {titulo}, Cantidad vendida: {cantidad}")